package com.demo.RestaurantOrderManagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.demo.RestaurantOrderManagement.Models.Order;
import com.demo.RestaurantOrderManagement.Models.OrderStatus;
import com.demo.RestaurantOrderManagement.Service.OrderService;
import com.demo.RestaurantOrderManagement.controller.OrderController;

public class OrderControllerTest {
	@InjectMocks
	private OrderController orderController;
	@Mock
	private OrderService orderService;
	private Order order;
	
	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
		order =new Order();
		order.setId(1l);
		
		order.setCustomerName("prakash");
		order.setCustomerPhone("578689678979");
		order.setStatus(OrderStatus.RECEIVED);
		order.setTotalAmount(29.67);
		order.setItems(Collections.emptyList());
	}
	
	@Test
	void testcreateorder()
	{
		when(orderService.createOrder(any(Order.class)))
		.thenReturn(order);
		ResponseEntity<Order> response=orderController.createOrder(order);
		assertEquals(HttpStatus.CREATED,response.getStatusCode());
		assertEquals(order,response.getBody());
	}
	@Test
	void testgetorderByid()
	{
		when(orderService.getOrderById(1l))
		.thenReturn(order);
		ResponseEntity<Order> response=orderController.getOrderById(1l);
		assertEquals(HttpStatus.CREATED,response.getStatusCode());
		assertEquals(order,response.getBody());
	}
	
	
	
	

}
