package com.demo.RestaurantOrderManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantOrderManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
