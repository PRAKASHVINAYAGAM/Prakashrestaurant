package com.demo.RestaurantOrderManagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.demo.RestaurantOrderManagement.Models.Category;
import com.demo.RestaurantOrderManagement.Models.MenuItem;
import com.demo.RestaurantOrderManagement.Service.MenuItemService;
import com.demo.RestaurantOrderManagement.controller.MenuItemController;

public class MenuItemControllerTest {
	@InjectMocks
    private MenuItemController menuItemController;

    @Mock
    private MenuItemService menuItemService;

    private MenuItem menuItem;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        menuItem = new MenuItem(); 
        menuItem.setId(1L);
        menuItem.setName("idly");
        menuItem.setPrice(9.9);
        menuItem.setAvailableQuantity(10);
        menuItem.setCategory(Category.MAIN_COURSE); 
    }

    @Test
    void testAddMenuItem() {
        when(menuItemService.createMenuItem(any(MenuItem.class))).thenReturn(menuItem);
        ResponseEntity<MenuItem> response = menuItemController.createMenuItem(menuItem);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(menuItem, response.getBody());
    }

    
}


