package com.demo.RestaurantOrderManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.RestaurantOrderManagement.Models.Category;
import com.demo.RestaurantOrderManagement.Models.MenuItem;
import com.demo.RestaurantOrderManagement.Service.MenuItemService;

@RestController
@RequestMapping("/api/menu-items ")
public class MenuItemController {
	@Autowired
	private MenuItemService menuItemService;
	
	@PostMapping
	 public ResponseEntity<MenuItem> createMenuItem(@RequestBody MenuItem menuItem)
	 {
		MenuItem createdMenuItem=menuItemService.createMenuItem(menuItem);
		return new ResponseEntity<MenuItem>(createdMenuItem, HttpStatus.CREATED);
	 }
	
	@GetMapping
	public ResponseEntity<List<MenuItem>> getAllMenuItem(@RequestParam (required =false) String category)
	{
		List<MenuItem> menuItem=menuItemService.getAllMenuItems(category);
		return new ResponseEntity<>(menuItem, HttpStatus.OK);
	}
	@GetMapping("/{id}")
	public ResponseEntity<MenuItem> getMenuItemById(@PathVariable Long id)
	{
		MenuItem menuItem=menuItemService.getMenuItemById(id).get();
		return new ResponseEntity<>(menuItem, HttpStatus.OK);
	}

	
	
	
	
	
	

}
