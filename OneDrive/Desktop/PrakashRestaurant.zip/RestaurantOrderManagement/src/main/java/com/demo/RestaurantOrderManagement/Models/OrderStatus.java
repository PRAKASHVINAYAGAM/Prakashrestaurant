package com.demo.RestaurantOrderManagement.Models;


public enum OrderStatus {
	
	RECEIVED, PREPARING, READY, DELIVERED

}
