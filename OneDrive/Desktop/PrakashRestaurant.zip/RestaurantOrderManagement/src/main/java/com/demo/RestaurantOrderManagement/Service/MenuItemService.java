package com.demo.RestaurantOrderManagement.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.RestaurantOrderManagement.Models.MenuItem;
import com.demo.RestaurantOrderManagement.Repository.MenuItemRepository;

@Service
public class MenuItemService {
	@Autowired
	private MenuItemRepository menuItemRepository;
	
	public MenuItem createMenuItem(MenuItem menuItem)
	{
		return menuItemRepository.save(menuItem);
		
	}
	
	public List<MenuItem> getAllMenuItems(String category)
	{
		if(category== null)
		{
			return menuItemRepository.findAll();
		}
		else
		{
			return menuItemRepository.findByCategory(category);
		}
	}
	
	
	public Optional<MenuItem> getMenuItemById(Long id)
	{
		return menuItemRepository.findById(id);
	}
	

}
