package com.demo.RestaurantOrderManagement.DTO;

import org.hibernate.validator.constraints.NotEmpty;

import jakarta.validation.constraints.Min;

public class MenuItemDTO {
	public MenuItemDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MenuItemDTO(@NotEmpty(message = "Menu item name is required") String name,
			@Min(value = 0, message = "price must be positive") Double price,
			@Min(value = 0, message = "Quantity must be positive") Integer availableQuantity, String category) {
		super();
		this.name = name;
		this.price = price;
		this.availableQuantity = availableQuantity;
		this.category = category;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Integer getAvailableQuantity() {
		return availableQuantity;
	}
	public void setAvailableQuantity(Integer availableQuantity) {
		this.availableQuantity = availableQuantity;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	@NotEmpty(message="Menu item name is required")
	private String name;
	@Min(value=0,message="price must be positive")
	private Double price;
	@Min(value=0,message="Quantity must be positive")
	private Integer availableQuantity;
	private String category;

}
