package com.demo.RestaurantOrderManagement.DTO;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class OrderItemDTO {
	
	public OrderItemDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderItemDTO(@NotNull(message = "Menu Item id is requiered") Long menuItemId,
			@Min(value = 1, message = "Quantity must be at least 1") Integer quantity) {
		super();
		this.menuItemId = menuItemId;
		this.quantity = quantity;
	}

	public Long getMenuItemId() {
		return menuItemId;
	}

	public void setMenuItemId(Long menuItemId) {
		this.menuItemId = menuItemId;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	@NotNull(message ="Menu Item id is requiered")
	private Long menuItemId;
	
	@Min(value =1,message ="Quantity must be at least 1")
	private Integer quantity;

}
