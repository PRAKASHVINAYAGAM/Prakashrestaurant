package com.demo.RestaurantOrderManagement.Models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class OrderItem {
	public OrderItem(Long id, int quantity, double subtotal) {
		super();
		this.id = id;
		this.quantity = quantity;
		this.subtotal = subtotal;
	}

	/*
	 * menuItem (MenuItem)
- quantity (Integer)
- subtotal (Double)
	 */

	@Id
	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getSubtotal() {
		return subtotal;
	}

	public void setSubtotal(double subtotal) {
		this.subtotal = subtotal;
	}

	public OrderItem() {
		super();
		// TODO Auto-generated constructor stub
	}

	private int quantity;
	
	private double subtotal;
	@ManyToOne
	private MenuItem menuItem;
	
	
	
}
