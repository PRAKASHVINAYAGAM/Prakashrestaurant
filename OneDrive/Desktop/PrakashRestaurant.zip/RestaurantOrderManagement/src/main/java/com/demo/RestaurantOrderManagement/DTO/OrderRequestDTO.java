package com.demo.RestaurantOrderManagement.DTO;

import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;

public class OrderRequestDTO {
	
	@NotEmpty(message="customer name is required")
	private String customerName;
	
	
	@NotEmpty(message="customer phone number is required")
	private String customerPhone;
	@NotEmpty(message="order item  is required")
	private List<OrderItemDTO> items;
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerPhone() {
		return customerPhone;
	}
	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}
	public List<OrderItemDTO> getItems() {
		return items;
	}
	public void setItems(List<OrderItemDTO> items) {
		this.items = items;
	}
	public OrderRequestDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OrderRequestDTO(@NotEmpty(message = "customer name is required") String customerName,
			@NotEmpty(message = "customer phone number is required") String customerPhone,
			@NotEmpty(message = "order item  is required") List<OrderItemDTO> items) {
		super();
		this.customerName = customerName;
		this.customerPhone = customerPhone;
		this.items = items;
	}

}
