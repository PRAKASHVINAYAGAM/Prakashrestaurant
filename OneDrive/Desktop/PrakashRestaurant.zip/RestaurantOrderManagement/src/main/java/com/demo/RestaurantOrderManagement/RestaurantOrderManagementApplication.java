package com.demo.RestaurantOrderManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantOrderManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantOrderManagementApplication.class, args);
	}

}
