package com.demo.RestaurantOrderManagement.Models;

public enum Category {
	APPETIZER, MAIN_COURSE, DESSERT
	

}
