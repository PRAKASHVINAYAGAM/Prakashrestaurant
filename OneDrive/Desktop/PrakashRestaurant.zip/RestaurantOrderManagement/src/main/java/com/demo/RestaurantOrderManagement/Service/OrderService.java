package com.demo.RestaurantOrderManagement.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.RestaurantOrderManagement.Models.Order;
import com.demo.RestaurantOrderManagement.Repository.OrderRepository;

@Service
public class OrderService {
	@Autowired
	private OrderRepository orderRepository;
	
	
	public Order createOrder(Order order)
	{
		return orderRepository.save(order);
	}
	
	public Order getOrderById(Long id)
	{
		return orderRepository.findById(id).get();
	}
	

}
